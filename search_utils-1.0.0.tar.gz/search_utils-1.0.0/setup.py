from distutils.core import setup

setup(
	name = 'search_utils',
	py_modules= ['search_utils'],
	version = '1.0.0',
	author = '',
	author_email = '',
	url = '',
	description = 'A simple function',
)